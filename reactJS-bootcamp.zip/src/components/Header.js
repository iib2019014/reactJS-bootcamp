import React from "react";

export default function Header() {
  return (
    <div>
      <header>
        <h1>ShapeAI - Boot Camps - Manvith Yadav</h1>
      </header>
    </div>
  );
}
