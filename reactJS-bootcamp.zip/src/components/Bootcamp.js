import React from "react";

export default function Bootcamp(props) {
  return (
    <div>
      <div className="note">
        <h2>{props.bootcamp_name}</h2>
        <p>{props.bootcamp_name}</p>
      </div>
    </div>
  );
}
